import { useState, useEffect } from 'react';
import { Shield, Menu, X } from 'lucide-react';
import Home from './pages/Home.jsx'; import Checker from './pages/Checker.jsx'; import Safety from './pages/Safety.jsx'; import About from './pages/About.jsx';
const NAV=[['home','Home'],['checker','Scam Checker'],['safety','Safety Center'],['about','About & Privacy']];
const fromHash=()=>{const h=location.hash.slice(1);return NAV.some(n=>n[0]===h)?h:'home'};
export default function App(){
  const [page,setPage]=useState(fromHash),[open,setOpen]=useState(false);
  useEffect(()=>{const f=()=>setPage(fromHash());addEventListener('hashchange',f);return()=>removeEventListener('hashchange',f)},[]);
  const go=p=>{location.hash=p;setOpen(false);scrollTo(0,0)};
  const P={home:<Home go={go}/>,checker:<Checker/>,safety:<Safety/>,about:<About/>}[page];
  return(<><a href="#main" className="skip" onClick={e=>{e.preventDefault();document.getElementById('main')?.focus()}}>Skip to content</a>
  <header className="nav"><div className="wrap navin"><button className="logo" onClick={()=>go('home')}><Shield size={22}/> TrustCheck</button>
  <button className="burger" aria-label="Toggle menu" aria-expanded={open} onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
  <nav className={open?'open':''} aria-label="Main">{NAV.map(([k,l])=><button key={k} className={page===k?'on':''} aria-current={page===k?'page':undefined} onClick={()=>go(k)}>{l}</button>)}</nav></div></header>
  <div id="main" tabIndex="-1">{P}</div>
  <footer><div className="wrap row between"><span>TrustCheck: Think Before You Trust. Educational demo, not a definitive detector.</span>
  <span><button onClick={()=>go('about')}>About</button> <button onClick={()=>go('about')}>Privacy</button> <button onClick={()=>go('safety')}>Safety Resources</button></span></div></footer></>);
}

const K='trustcheck.history.v1';
export const loadHistory=()=>{try{return JSON.parse(localStorage.getItem(K))||[]}catch{return[]}};
export const saveEntry=e=>{try{const h=[e,...loadHistory()].slice(0,20);localStorage.setItem(K,JSON.stringify(h));return h}catch{return null}};
export const clearHistory=()=>{try{localStorage.removeItem(K)}catch{}};

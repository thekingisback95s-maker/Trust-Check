// Transparent rule-based engine. No network calls, no AI, no threat intelligence.
import { computeRisk, categoryFor } from './scoring.js';
export const RULES = [
 { id:'cred', t:'Asks for passwords, PINs or verification codes', w:50, ctx:/(send|share|reply|provide|enter|give|confirm|tell|submit|forward|read out)/i, re:/(login (details|credentials)|username and password|password|passcode|\bpin\b|\botp\b|verification code|security code|one[- ]time (code|password)|card number|\bcvv\b)/i,
   why:'Real banks and services never ask you to share codes or passwords by message. Anyone holding a code can take over your account.' },
 { id:'fee', t:'Asks for a payment to get a job or prize', w:50, ctx:/(job|role|position|employ|hire|hiring|applic|offer|prize|won|win|claim|secure|selected|onboard|interview|vacancy)/i, re:/((application|registration|processing|training|medical|visa|clearance|onboarding|equipment) fee|pay .{0,40}(to secure|to get|to receive|to start|before)|refundable deposit)/i,
   why:'Legitimate employers do not charge applicants. Upfront fees are a classic advance-fee pattern.' },
 { id:'urg', t:'Urgency or threats', w:20, re:/(urgent(ly)? (action|response|attention|payment|reply)|(act|reply|respond|pay|send|verify|confirm|click|transfer) (now|immediately|right away|today|asap)|(or|otherwise|else) .{0,40}(suspended|closed|blocked|cancelled|forfeit|lose)|final notice|last chance|(account|card|number|access) (will be |has been )?(suspended|closed|blocked|locked|deactivated)|expires? (today|tonight))/i,
   why:'Pressure is used to stop you from thinking or checking. Genuine organisations normally allow time to verify.' },
 { id:'ret', t:'Guaranteed returns or unrealistic rewards', w:40, re:/(guaranteed (returns?|profits?|income)|risk[- ]free|double your|\d{2,}% (daily|weekly|monthly)|get rich|easy money|make money fast|you('ve| have) (won|been selected for a prize))/i,
   why:'Real investments carry risk and no one can guarantee profit. Outsized promised rewards are a hallmark of investment and prize scams.' },
 { id:'pay', t:'Unusual payment method', w:30, ctx:/(pay|send|transfer|deposit|buy|purchase|using|via|wallet|redeem)/i, re:/(gift ?cards?|bitcoin|\busdt\b|crypto(currency)?|western union|moneygram|wire transfer|send (it )?to my (personal )?account)/i,
   why:'Gift cards, crypto and wire transfers are hard to reverse, which is why fraudsters prefer them.' },
 { id:'threat', t:'Threatens consequences unless you pay', w:35, ctx:/(pay|settle|clear|transfer|deposit)/i, re:/(legal action|arrest warrant|will be (arrested|prosecuted|sued)|face (arrest|prosecution|legal)|police will)/i,
   why:'Threats of arrest or legal action tied to a payment are a common intimidation tactic. Real authorities do not demand instant payment by message.' },
 { id:'pii', t:'Requests sensitive personal information', w:30, re:/(\bssn\b|social security|passport (number|scan|copy)|national id|\bnin\b|\bbvn\b|date of birth|mother'?s maiden|id card)/i,
   why:'Sensitive identity details can be used for identity theft. Share them only through channels you have verified yourself.' },
 { id:'imp', t:'Claims to be a well-known organisation', w:12, re:/((this is|we are|from) (the |your )?.{0,25}(bank|amazon|paypal|dhl|fedex|ups|microsoft|apple|revenue service|police|customer care|security team))/i,
   why:'Impersonating trusted names is common. This tool cannot verify who actually sent the message.' },
 { id:'chan', t:'Moves the conversation to a private chat app', w:8, re:/(whatsapp|telegram|signal me|text me on)/i,
   why:'Scammers often move targets to private chats with less oversight. Many genuine recruiters use them too, so this is a weak signal alone.' },
 { id:'link', t:'Shortened link in the message', w:20, re:/(bit\.ly|tinyurl\.com|t\.co\/|cutt\.ly|rb\.gy|is\.gd|shorturl)/i,
   why:'Short links hide the real destination. Do not click until you know where it leads.' },
 { id:'greet', t:'Generic greeting', w:4, re:/(dear (customer|user|applicant|candidate|client|sir\/madam|beneficiary))/i,
   why:'Mass messages often use generic greetings. Many legitimate bulk emails do as well.' },
];
const UNVERIFIED = ['Who actually sent the message','Whether the sender’s domain, phone number or account is genuine','Whether any link is safe to open','Whether any bank account, company or offer really exists'];

export function analyseUrl(url){
  const out=[]; const u=(url||'').trim(); if(!u) return out;
  const add=(t,w,why)=>out.push({id:'url-'+out.length,t,w,why,evidence:u});
  let host=u; try{ host=new URL(/^[a-z]+:\/\//i.test(u)?u:'http://'+u).hostname; }catch{}
  if(/^http:\/\//i.test(u)) add('Link does not use HTTPS',8,'Missing HTTPS is a weak signal on its own, but legitimate sign-in pages use it.');
  if(/(bit\.ly|tinyurl|t\.co|cutt\.ly|rb\.gy|is\.gd)/i.test(host)) add('Shortened URL',15,'Short links hide the destination.');
  if(/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) add('URL uses a raw IP address',20,'Genuine organisations almost always use a named domain.');
  if(/xn--/.test(host)) add('Possible look-alike (punycode) domain',18,'Punycode can disguise characters that look like normal letters.');
  if(u.includes('@')) add('URL contains an @ symbol',12,'Text before @ can disguise the real destination.');
  if((host.match(/-/g)||[]).length>=3) add('Many hyphens in the domain',10,'Long hyphenated names are often used to imitate brands.');
  if(/\.(xyz|top|click|icu|work|buzz|rest)$/i.test(host)) add('Domain ending often seen in bulk abuse',8,'These endings are cheap and widely used, but plenty of legitimate sites use them too.');
  return out;
}
export const category=categoryFor;

export const MAX_CHARS=5000;
export function analyse(text,type,url){
  text=String(text??'').normalize('NFC').slice(0,MAX_CHARS); type=String(type||'Message'); url=String(url??'').slice(0,500);
  const sentences=text.split(/(?<=[.!?\n])\s+/);
  const found=[]; const notFound=[];
  RULES.forEach(r=>{
    const sent=sentences.find(x=>r.re.test(x)&&(!r.ctx||r.ctx.test(x)));
    const m=r.ctx?sent:text.match(r.re);
    if(m){ const ev=(sent||m[0]).trim().slice(0,200); found.push({id:r.id,t:r.t,w:r.w,why:r.why,evidence:ev}); }
    else notFound.push(r.t);
  });
  analyseUrl(url).forEach(f=>found.push(f));
  const {score,category:cat}=computeRisk(found); // score and category come from one calculation
  const summary=found.length===0
    ?'No common warning signs were found in this text. That does not prove the message is genuine.'
    :`${found.length} warning sign${found.length>1?'s were':' was'} found in this ${type.toLowerCase()}. ${cat==='Low'||cat==='Moderate'?'Treat it with care and verify through an official channel.':'Several serious signals appear together, so do not act on it until you verify independently.'}`;
  const actions=['Verify the sender using contact details you find yourself, not those in the message.'];
  const ids=found.map(f=>f.id);
  if(ids.includes('cred')) actions.unshift('Never share codes, PINs or passwords. If you already did, contact your bank and change the password now.');
  if(ids.includes('fee')||ids.includes('ret')||ids.includes('pay')) actions.unshift('Do not send money. Genuine employers and investments do not need upfront or unusual payments.');
  if(ids.includes('link')||found.some(f=>f.id.startsWith('url'))) actions.push('Do not open the link. Type the official website address yourself.');
  if(ids.includes('pii')) actions.push('Keep identity documents private until you have verified the organisation.');
  if(found.length) actions.push('Report it to the platform or an official fraud service (see the Safety Center).');
  return {id:Date.now(),date:new Date().toISOString(),type,score,category:cat,summary,found,notFound,unverified:UNVERIFIED,actions};
}
export function toText(r){
  const sign=r.found.length?r.found.map(f=>`- ${f.t}: ${f.why}`).join('\n'):'- none detected';
  return `TrustCheck report (${r.type})
Heuristic risk score: ${r.score}/100 (${r.category} risk). This is a rule-based estimate, not a probability of fraud.
${r.summary}

Warning signs detected:
${sign}

Not detected: ${r.notFound.length?r.notFound.join('; '):'none'}

Not verified by TrustCheck: ${r.unverified.join('; ')}

Recommended actions:
${r.actions.map(a=>'- '+a).join('\n')}

Preliminary pattern-based screening. Low risk does not prove a message is genuine; high risk does not prove fraud. The message text is not included in this report.`;
}
export const EXAMPLES=[
 {label:'Fake job: application fee',type:'Job offer',sender:'',text:'Congratulations! You have been selected for the Remote Data Entry role at $400 per day. No experience needed. To secure your position you must pay a $50 registration fee today. Reply on WhatsApp to receive payment details. Dear Applicant, act now as slots close within 24 hours.'},
 {label:'Bank: verification code',type:'SMS',sender:'',text:'This is your bank security team. Unusual login detected, your account will be suspended. Reply immediately with the verification code sent to you and your PIN to restore access.'},
 {label:'Crypto: guaranteed returns',type:'Business offer',sender:'',text:'Join our private crypto group. Guaranteed returns of 40% weekly, risk-free! Send USDT to my wallet to double your money. Limited spots, act now.'},
 {label:'Threat: payment demand',type:'SMS',sender:'',text:'Final notice: you owe an outstanding fine of 50,000 naira. Pay today or legal action will follow and you may face arrest.'},
 {label:'Harmless work meeting',type:'Email',sender:'',text:'Hi team, the weekly project meeting is moved to 3pm on Thursday in Room 4. Please bring your updated reports. Thanks, Ade.'},
 {label:'Normal interview invitation',type:'Email',sender:'',text:'Hello Amina, thank you for applying for the Junior Designer position. We would like to invite you to an interview on Thursday at 2pm via video call. Please reply to confirm whether this time suits you. Kind regards, the recruitment team.'},
 {label:'Delivery: odd payment request',type:'SMS',sender:'http://parcel-redelivery-track-now.xyz/pay',text:'Your parcel is held at the depot. Pay a 2.99 redelivery fee using gift cards today or it will be returned. Details: bit.ly/3xYz12'},
];

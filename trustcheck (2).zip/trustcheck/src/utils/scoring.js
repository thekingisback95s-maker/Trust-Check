// Single source of truth for the heuristic risk score and risk category.
// The score is an internal heuristic estimate. It is NOT a probability of fraud.

// Category thresholds (inclusive lower bound). Documented and used everywhere.
export const THRESHOLDS = [
  { min: 70, category: 'Very High' }, // several serious signals together
  { min: 45, category: 'High' },      // at least one strong signal, e.g. an upfront fee or a request for a code
  { min: 20, category: 'Moderate' },  // pressure or other medium signals worth verifying
  { min: 0,  category: 'Low' },       // no meaningful signals, or only trivial ones
];

// Rules in the same family describe the same underlying behaviour, so they are not added in full.
export const FAMILY = { threat:'pressure', fee:'payment', pay:'payment', cred:'secrets', pii:'secrets', urg:'pressure', ret:'reward', link:'link', imp:'identity', greet:'identity', chan:'channel' };
export const familyOf = id => FAMILY[id] || (id.startsWith('url-') ? 'link' : id);
const OVERLAP = 0.3; // extra rules in a family add only 30% of their points

export const clampScore = s => Math.max(0, Math.min(100, Math.round(Number(s) || 0)));
export const categoryFor = s => THRESHOLDS.find(t => clampScore(s) >= t.min).category;

/** found: [{id, w}] -> { score, category }. Both come from the same number. */
export function computeRisk(found = []) {
  const fam = {};
  // A generic greeting is only meaningful alongside other signals.
  if (!found.some(f => f.id !== 'greet')) found = [];
  for (const f of found) (fam[familyOf(f.id)] ||= []).push(f.w);
  let total = 0;
  for (const ws of Object.values(fam)) {
    ws.sort((a, b) => b - a);
    total += ws[0] + OVERLAP * ws.slice(1).reduce((a, b) => a + b, 0);
  }
  const score = clampScore(total);
  return { score, category: categoryFor(score) };
}

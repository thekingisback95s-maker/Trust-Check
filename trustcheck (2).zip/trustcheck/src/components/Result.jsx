import { useState } from 'react';
import { Copy, Check, RotateCcw, ShieldAlert, ShieldCheck, EyeOff, HelpCircle } from 'lucide-react';
import { toText } from '../utils/engine.js';
import { clampScore, categoryFor } from '../utils/scoring.js';
export default function Result({r:raw,onAgain}){
  const score=clampScore(raw.score), r={...raw,score,category:categoryFor(score)}; // always consistent, even for old history entries
  const [ok,setOk]=useState(false),[msg,setMsg]=useState('');
  const copy=async()=>{try{await navigator.clipboard.writeText(toText(r));setOk(true);setMsg('Report copied to clipboard.');setTimeout(()=>setOk(false),2000)}catch{setMsg('Copy failed. Your browser blocked clipboard access; select the text and copy it manually.')}};
  const cls={Low:'ok',Moderate:'mid',High:'bad','Very High':'bad'}[r.category];
  return(<section className="card result" aria-live="polite">
    <div className="rhead"><div className={`gauge ${cls}`} role="img" aria-label={`Risk ${r.category}, score ${r.score} of 100`}><strong>{r.score}</strong><span>/100</span></div>
    <div><h2>{r.category} risk {cls==='ok'?<ShieldCheck size={22}/>:<ShieldAlert size={22}/>}</h2><p>{r.summary}</p>
    <p className="small">Heuristic risk score from simple rules. It is not a probability of fraud.</p></div></div>
    <div className="bar" aria-hidden="true"><i className={cls} style={{width:r.score+'%'}}/></div>
    <h3>Warning signs detected ({r.found.length})</h3>
    {r.found.length===0&&<p className="empty">Nothing matched our rules. Keep verifying anyway.</p>}
    <ul className="signs">{r.found.map(f=><li key={f.id}><b>{f.t}</b><p>{f.why}</p>{f.evidence&&<blockquote>“{f.evidence}”</blockquote>}</li>)}</ul>
    <div className="two"><div><h3><EyeOff size={16}/> Not detected</h3><p className="small">{r.notFound.length?r.notFound.join('; '):'All rule categories matched.'}</p></div>
    <div><h3><HelpCircle size={16}/> Could not be verified</h3><ul className="small">{r.unverified.map(u=><li key={u}>{u}</li>)}</ul></div></div>
    <h3>Recommended actions</h3><ul>{r.actions.map(a=><li key={a}>{a}</li>)}</ul>
    <p className="note">Preliminary screening only. Low risk does not guarantee legitimacy, and high risk does not prove fraud. No sender, link, company or bank check was performed; TrustCheck only looks for patterns in the text.</p>
    <div className="row"><button className="btn pri" onClick={onAgain}><RotateCcw size={16}/> Analyze another message</button>
    <button className="btn" onClick={copy}>{ok?<Check size={16}/>:<Copy size={16}/>} {ok?'Copied':'Copy results'}</button></div>
    <p role="status" className="small">{msg}</p>
  </section>);
}

import { ScanSearch, MessageSquareWarning, ListChecks, ClipboardPaste, Cpu, ShieldCheck } from 'lucide-react';
const FAQ=[['Is TrustCheck always right?','No. It is an educational screening tool that checks simple, visible rules. It cannot prove a message is real or fake.'],
['Is my message uploaded?','No. Analysis happens in your browser. Nothing is sent to a server in this demo.'],['Does it use AI?','No. It uses a transparent rule-based engine, and does not use live threat intelligence.']];
export default function Home({go}){
  return(<main><section className="hero"><div className="wrap hgrid"><div>
    <p className="tag">Think Before You Trust.</p><h1>One suspicious message can cost you everything.</h1>
    <p className="lead">TrustCheck shows the warning signs hidden in job offers, emails, texts and links, and explains each one in plain language.</p>
    <div className="row"><button className="btn pri big" onClick={()=>go('checker')}>Check a Message</button><button className="btn ghost big" onClick={()=>go('safety')}>Explore Safety Tips</button></div></div>
    <div className="preview" aria-label="Example analysis preview"><div className="gauge bad"><strong>82</strong><span>/100</span></div><h3>Very High risk (sample)</h3>
    <ul><li>Asks for a payment to get a job</li><li>Urgency or threats</li><li>Moves chat to a private app</li></ul><p className="small">Fictional sample result</p></div></div></section>
  <section className="wrap sec"><h2>What you get</h2><div className="grid3">
    {[[ScanSearch,'Warning sign detection','Ten transparent rules plus URL pattern checks.'],[MessageSquareWarning,'Plain-language explanations','Each flag says why it matters and quotes the text.'],[ListChecks,'Safety recommendations','Next steps tailored to what was found.']].map(([I,t,d])=><div className="card" key={t}><I size={26}/><h3>{t}</h3><p>{d}</p></div>)}</div></section>
  <section className="wrap sec"><h2>How it works</h2><ol className="grid3">
    {[[ClipboardPaste,'Paste','Add the message, and a URL if you have one.'],[Cpu,'Analyze','Rules run locally in your browser.'],[ShieldCheck,'Decide','Read the signs, then verify through official channels.']].map(([I,t,d])=><li className="card" key={t}><I size={24}/><h3>{t}</h3><p>{d}</p></li>)}</ol></section>
  <section className="wrap sec"><h2>Supported message types</h2><div className="chips">{['SMS','Email','Job offer','Website link','Business offer'].map(t=><span className="chip" key={t}>{t}</span>)}</div></section>
  <section className="wrap sec"><h2>Frequently asked questions</h2>{FAQ.map(([q,a])=><details key={q} className="card"><summary>{q}</summary><p>{a}</p></details>)}</section></main>);
}

import { useState } from 'react';
import { Search, Trash2, Loader2, History, AlertTriangle } from 'lucide-react';
import { analyse, EXAMPLES } from '../utils/engine.js';
import { loadHistory, saveEntry, clearHistory } from '../utils/storage.js';
import Result from '../components/Result.jsx';
const TYPES=['SMS','Email','Job offer','Website link','Business offer'];
export default function Checker(){
  const [text,setText]=useState(''),[type,setType]=useState('SMS'),[url,setUrl]=useState(''),[save,setSave]=useState(false);
  const [err,setErr]=useState(''),[busy,setBusy]=useState(false),[res,setRes]=useState(null),[hist,setHist]=useState(loadHistory);
  const run=e=>{e.preventDefault();setErr('');
    if(text.trim().length<20&&!(type==='Website link'&&url.trim())){setErr('Enter at least 20 characters of the message, or a URL for a website link.');return}
    setBusy(true);setRes(null);
    setTimeout(()=>{let r;try{r=analyse(text,type,url)}catch{setErr('Analysis failed on this input. Try shorter plain text.');setBusy(false);return}setRes(r);setBusy(false);
      if(save){const h=saveEntry({id:r.id,date:r.date,type:r.type,score:r.score,category:r.category,summary:r.summary,found:r.found.map(f=>({...f,evidence:undefined})),notFound:r.notFound,unverified:r.unverified,actions:r.actions});if(h)setHist(h);else setErr('History could not be saved (browser storage unavailable).')}},700)};
  const clear=()=>{setText('');setUrl('');setErr('');setRes(null)};
  const wipe=()=>{if(confirm('Delete all saved history from this browser?')){clearHistory();setHist([])}};
  return(<main className="wrap page"><h1>Scam checker</h1>
  <p className="lead">Paste a message and TrustCheck explains which warning signs it contains. Analysis runs entirely in your browser.</p>
  <div className="warn"><AlertTriangle size={18}/> Remove passwords, PINs, card numbers and one-time codes before pasting.</div>
  <div className="grid2"><form className="card" onSubmit={run} noValidate>
    <label htmlFor="type">Message type</label><select id="type" value={type} onChange={e=>setType(e.target.value)}>{TYPES.map(t=><option key={t}>{t}</option>)}</select>
    <label htmlFor="url">Sender or website URL (optional)</label><input id="url" value={url} onChange={e=>setUrl(e.target.value)} placeholder="e.g. http://example-site.xyz/login"/>
    <label htmlFor="msg">Message text</label><textarea id="msg" rows="9" value={text} onChange={e=>setText(e.target.value)} maxLength={5000} aria-describedby="cnt" placeholder="Paste the suspicious message here…"/>
    <div id="cnt" className="small">{text.length} / 5000 characters</div>
    {err&&<p role="alert" className="err">{err}</p>}
    <label className="chk"><input type="checkbox" checked={save} onChange={e=>setSave(e.target.checked)}/> Save a summary to local history. The message text itself is never stored.</label>
    <div className="row"><button className="btn pri" disabled={busy}>{busy?<Loader2 className="spin" size={16}/>:<Search size={16}/>} {busy?'Analyzing…':'Analyze'}</button>
    <button type="button" className="btn" onClick={clear}><Trash2 size={16}/> Clear</button></div>
    <h3>Demonstration examples</h3><div className="chips">{EXAMPLES.map(x=><button type="button" key={x.label} className="chip" onClick={()=>{setText(x.text);setType(x.type);setUrl(x.sender);setRes(null);setErr('')}}>{x.label}</button>)}</div>
    <p className="small">Fictional demonstrations, not real reports. Loading one fills the form; press Analyze to run it.</p></form>
    <div>{busy&&<div className="card empty">Checking message against local rules…</div>}
    {!busy&&!res&&<div className="card empty">Results appear here. Paste a message or load an example to start.</div>}
    {res&&<Result r={res} onAgain={clear}/>}</div></div>
  <section className="card"><div className="row between"><h2><History size={20}/> Recent analyses</h2>{hist.length>0&&<button className="btn" onClick={wipe}>Clear history</button>}</div>
    <p className="small">Stored only in this browser using localStorage. Clearing browser data removes it.</p>
    {hist.length===0?<p className="empty">No saved analyses yet. Tick “Save a summary” before analyzing.</p>:
    <ul className="hl">{hist.map(h=><li key={h.id}><button className="hbtn" onClick={()=>setRes(h)}><b>{h.category}</b> · {h.type} · {new Date(h.date).toLocaleString()}<br/><span className="small">{h.summary}</span></button></li>)}</ul>}</section></main>);
}

export default function About(){return(<main className="wrap page narrow"><h1>About and privacy</h1>
<h2>Purpose</h2><p>TrustCheck helps students, job seekers and small businesses recognise common online scam warning signs.</p>
<h2>How the demo works</h2><p>Version 1 uses local rule-based analysis in your browser. It is not a trained machine-learning model and has no live threat-intelligence database. It cannot verify senders, domains, bank accounts or website safety.</p>
<h2>Limitations</h2><p>Low risk does not guarantee legitimacy. High risk does not prove fraud. Always verify through official channels.</p>
<h2>Privacy</h2><p>Messages are not sent anywhere. If you opt in, a summary (type, date, score, warning-sign names) is saved in this browser’s localStorage, never the message text. Clear it any time from the Scam checker page. TrustCheck has not undergone any security audit or certification.</p></main>)}

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { analyse, toText, EXAMPLES, MAX_CHARS } from '../src/utils/engine.js';
import { THRESHOLDS, categoryFor, computeRisk } from '../src/utils/scoring.js';
const run = t => analyse(t, 'SMS', '');
const has = (r, id) => r.found.some(f => f.id === id);
const T = {
  meeting: 'Hi team, the weekly project meeting is moved to 3pm on Thursday. Please bring your reports. Thanks, Ade.',
  urgentMeeting: 'This is an urgent meeting about the budget; please attend.',
  fee: 'To secure your position, pay a ₦15,000 registration fee today.',
  otp: 'Please reply with your OTP to continue.',
  threat: 'Final notice: pay the outstanding fine of ₦50,000 today or legal action will follow.',
  invest: 'Invest ₦100,000 now with guaranteed returns of 50% weekly. Risk-free!',
  harmless: 'Your invoice payment of ₦25,000 was received. Your account statement is attached. Contact your account manager with questions.',
  multi: 'This is your bank security team. Act now, your account will be suspended. Reply with the verification code and your BVN, or pay via gift cards. Guaranteed returns await.',
};
test('1 harmless meeting is Low (also with the word urgent)', () => {
  for (const t of [T.meeting, T.urgentMeeting]) { const r = run(t); assert.equal(r.score, 0); assert.equal(r.category, 'Low'); }
});
test('2 fee request triggers upfront-payment warning', () => { const r = run(T.fee); assert.ok(has(r, 'fee')); assert.equal(r.category, 'High'); });
test('3 OTP request is a serious warning', () => { const r = run(T.otp); assert.ok(has(r, 'cred')); assert.ok(r.score >= 45); });
test('4 threat plus payment demand is flagged', () => { const r = run(T.threat); assert.ok(has(r, 'threat')); assert.ok(has(r, 'urg')); assert.ok(r.score >= 20); });
test('5 guaranteed returns is flagged', () => { const r = run(T.invest); assert.ok(has(r, 'ret')); assert.ok(r.score >= 40); });
test('6 multiple signs combine without exceeding raw sum', () => {
  const r = run(T.multi); assert.ok(r.found.length >= 4);
  const raw = r.found.reduce((a, f) => a + f.w, 0);
  assert.equal(r.score, computeRisk(r.found).score); assert.ok(r.score < raw); assert.equal(r.category, 'Very High');
});
test('7 repeated wording does not inflate the score', () => {
  assert.equal(run(T.otp).score, run((T.otp + ' ').repeat(10)).score);
  assert.equal(run('Send your OTP now. ').score, run('Send your OTP now. '.repeat(20)).score);
});
test('8 ordinary payment/account wording is not a scam', () => { const r = run(T.harmless); assert.equal(r.score, 0); assert.equal(r.category, 'Low'); });
test('8b generic greeting alone scores 0', () => assert.equal(run('Dear customer, our newsletter is ready.').score, 0));
test('9 empty and invalid input handled', () => {
  for (const v of ['', '   ', null, undefined, 42]) { const r = analyse(v, 'SMS', undefined); assert.equal(r.category, categoryFor(r.score)); assert.ok(r.score >= 0 && r.score <= 100); }
  assert.equal(analyse('', 'SMS', '').score, 0);
});
test('10 very long input is safe and fast', () => {
  const t0 = Date.now();
  for (const big of ['a'.repeat(2e6), 'urgent '.repeat(3e5), ('pay '.repeat(50) + '.').repeat(1e5)]) assert.ok(analyse(big, 'Email', 'x'.repeat(1e5)).score <= 100);
  assert.ok(Date.now() - t0 < 3000); assert.equal(MAX_CHARS, 5000);
});
test('11 unusual punctuation and Unicode do not crash', () => {
  for (const t of ['😀 ₦ 𝒫𝒶𝓈𝓈 \u0000 \uD800 (((((  [[[ *** \\ ^$ .*+? |', '\u202Eevil\u202C ‮ ﷽ ‼‽ ⁇', '(?:a+)+$ '.repeat(500)]) assert.doesNotThrow(() => run(t));
});
test('12-13 scores bounded and labels match thresholds for all inputs', () => {
  const inputs = [...Object.values(T), ...EXAMPLES.map(x => x.text), ''];
  for (const t of inputs) { const r = run(t); assert.ok(Number.isInteger(r.score) && r.score >= 0 && r.score <= 100); assert.equal(r.category, categoryFor(r.score)); }
  for (let s = 0; s <= 100; s++) { const exp = THRESHOLDS.find(x => s >= x.min).category; assert.equal(categoryFor(s), exp); }
});
test('14 copy report is useful and omits message text', () => {
  const r = analyse('Reply with your OTP. My number is SECRET123', 'SMS', ''); const t = toText(r);
  assert.ok(t.includes(`${r.score}/100`) && t.includes(r.category)); assert.ok(t.includes('Asks for passwords')); assert.ok(t.includes('Recommended actions')); assert.ok(!t.includes('SECRET123'));
});
test('15 UI results list what could not be verified', () => {
  const u = run(T.fee).unverified.join(' ').toLowerCase(); for (const k of ['sender', 'link', 'bank']) assert.ok(u.includes(k));
});
test('16 source never claims verification or sends data out', () => {
  const walk = d => readdirSync(d).flatMap(f => { const p = join(d, f); return statSync(p).isDirectory() ? walk(p) : [p]; });
  for (const f of walk('src').filter(p => /\.(jsx?|css)$/.test(p))) {
    const s = readFileSync(f, 'utf8');
    assert.ok(!/(sender|company|url|bank account|domain) (has been |is |was )verified/i.test(s), f);
    assert.ok(!/\b(fetch\(|XMLHttpRequest|sendBeacon|WebSocket)/.test(s), f + ' makes a network call');
  }
});
test('examples stay differentiated', () => {
  const by = Object.fromEntries(EXAMPLES.map(x => [x.label, analyse(x.text, x.type, x.sender)]));
  assert.equal(by['Harmless work meeting'].category, 'Low'); assert.equal(by['Normal interview invitation'].category, 'Low');
  assert.ok(by['Threat: payment demand'].score >= 20); assert.equal(by['Bank: verification code'].category, 'Very High');
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { analyse, EXAMPLES } from '../src/utils/engine.js';
import { categoryFor, computeRisk } from '../src/utils/scoring.js';

const cases = {
  fee: 'To secure your position, pay a ₦15,000 registration fee today.',
  code: 'Please reply with your bank password and the one-time verification code we sent you.',
  urgency: 'Urgent: act now or your account will be suspended within 2 hours.',
  interview: 'Hello Amina, we would like to invite you to an interview on Thursday at 2pm via video call. Please confirm if this suits you.',
  many: 'This is your bank security team. Act now, your account will be suspended. Reply with the verification code and your BVN, or pay via gift cards. Guaranteed returns if you click bit.ly/x1',
};
const run = t => analyse(t, 'SMS', '');
const rank = { Low: 0, Moderate: 1, High: 2, 'Very High': 3 };

test('upfront registration fee is not scored 0 and is High', () => {
  const r = run(cases.fee);
  assert.ok(r.found.some(f => f.id === 'fee'));
  assert.ok(r.score >= 45); assert.equal(r.category, 'High');
});
test('password / one-time code request is High or above', () => {
  const r = run(cases.code); assert.ok(rank[r.category] >= 2);
});
test('urgency and threats are Moderate, not High', () => {
  const r = run(cases.urgency); assert.ok(r.found.some(f => f.id === 'urg')); assert.equal(r.category, 'Moderate');
});
test('normal interview invitation is Low', () => {
  const r = run(cases.interview); assert.equal(r.found.length, 0); assert.equal(r.score, 0); assert.equal(r.category, 'Low');
});
test('several warning signs give Very High', () => {
  const r = run(cases.many); assert.ok(r.found.length >= 4); assert.equal(r.category, 'Very High');
});
test('same-behaviour rules are not double counted', () => {
  const both = computeRisk([{id:'fee',w:50},{id:'pay',w:30}]).score;
  assert.ok(both < 80); assert.ok(both > 50);
});
test('score is bounded 0-100', () => {
  assert.equal(computeRisk(Array(20).fill({id:'ret',w:40}).map((x,i)=>({id:'a'+i,w:90}))).score, 100);
  assert.equal(computeRisk([]).score, 0);
});
test('threshold boundaries', () => {
  [[0,'Low'],[19,'Low'],[20,'Moderate'],[44,'Moderate'],[45,'High'],[69,'High'],[70,'Very High'],[100,'Very High']]
    .forEach(([s, c]) => assert.equal(categoryFor(s), c));
});
test('displayed score always matches displayed category (all cases and examples)', () => {
  const all = [...Object.values(cases), ...EXAMPLES.map(x => x.text)];
  for (const t of all) { const r = run(t); assert.equal(r.category, categoryFor(r.score)); assert.ok(r.score >= 0 && r.score <= 100); }
});
test('example messages still differ sensibly', () => {
  const by = Object.fromEntries(EXAMPLES.map(x => [x.label, analyse(x.text, x.type, x.sender)]));
  assert.equal(by['Normal interview invitation'].category, 'Low');
  assert.ok(rank[by['Fake job: application fee'].category] >= 2);
});
